./emojivm ./chal.evm
