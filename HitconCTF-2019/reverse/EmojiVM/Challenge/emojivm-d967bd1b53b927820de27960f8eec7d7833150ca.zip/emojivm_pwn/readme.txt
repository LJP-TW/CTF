The challenge binary is the same as the one in emojivm_reverse/
