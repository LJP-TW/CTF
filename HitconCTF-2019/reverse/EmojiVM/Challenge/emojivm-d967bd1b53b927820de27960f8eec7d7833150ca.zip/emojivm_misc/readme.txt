Your task is simple: create an emoji file that can be executed by our EmojiVM and output a 9x9 multiplication table.

The output should be like this:

1 * 1 = 1                                                                       
1 * 2 = 2 
1 * 3 = 3 
1 * 4 = 4 
1 * 5 = 5 
1 * 6 = 6 
1 * 7 = 7 
1 * 8 = 8 
1 * 9 = 9 
2 * 1 = 2
2 * 2 = 4
.........
9 * 9 = 81

You can check the entire output in answer.txt. Make sure your output matches the content in that file. EVERY SINGLE CHARACTER MATTERS.  

If your emoji program output the answer correctly, you'll get the flag :)

Notice:  
* The EmojiVM in this challenge will NOT read your input while executing your emoji file.  
* I've added some filter/sandbox protection in this challenge so don't bother trying to pwn it ;)  

